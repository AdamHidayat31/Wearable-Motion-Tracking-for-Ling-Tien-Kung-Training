// generated from rosidl_generator_c/resource/idl.h.em
// with input from builtin_interfaces:msg/Duration.idl
// generated code does not contain a copyright notice

#ifndef BUILTIN_INTERFACES__MSG__DURATION_H_
#define BUILTIN_INTERFACES__MSG__DURATION_H_

#include "builtin_interfaces/msg/detail/duration__struct.h"
#include "builtin_interfaces/msg/detail/duration__functions.h"
#include "builtin_interfaces/msg/detail/duration__type_support.h"

#endif  // BUILTIN_INTERFACES__MSG__DURATION_H_
